##' The GAUL map border
##'
##' The geographic polygon used in the statistical year book
##'
##' @docType data
##' @keywords datasets
##' @name GAULspatialPolygon
##'
NULL

